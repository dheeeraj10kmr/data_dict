Oracle� Transportation Management
Data Dictionary ReadMe

Copyright � 2004, 2023, Oracle and/or its affiliates.
==================================================================================

The following zip file contains the Oracle Transportation Management Data 
Dictionary, the Transportation Intelligence and Global Trade Intelligence, and the 
Data Dictionary Diagrams for Transportation and Global Trade Management. 

data_dictionary.zip

This is the data model in easy to navigate HTML hyperlink format. Each table 
shows the columns, datatype, length, etc. You can navigate to the related 
tables by following the foreign key links. A comment about the table and 
columns is also provided.
 
Installation
~~~~~~~~~~~~

To install the data dictionary, perform the following steps:

1. Unzip data_dictionary.zip into a directory on your machine. 
2. In the data_dictionary folder, launch index.html to access all of the data dictionary content.

Technical Support
~~~~~~~~~~~~~~~~~

If you have problems with the software, contact Support at 
https://support.oracle.com or find the Support phone number for your region 
at https://www.oracle.com/support/contact.html.

